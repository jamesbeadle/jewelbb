<script lang="ts">
	import Seo from '$lib/components/Seo.svelte';
	import BadgeStrip from '$lib/components/BadgeStrip.svelte';
	import TestimonialCard from '$lib/components/TestimonialCard.svelte';
	import CtaBand from '$lib/components/CtaBand.svelte';
	import { site } from '$lib/data/site';
	import { images } from '$lib/data/images';
	import { services } from '$lib/data/services';
	import { testimonials } from '$lib/data/testimonials';
	import { projects } from '$lib/data/projects';

	const featured = projects.filter((p) => p.gallery.length > 0).slice(0, 3);

	const jsonLd = {
		'@context': 'https://schema.org',
		'@type': 'HomeAndConstructionBusiness',
		name: site.name,
		url: site.url,
		telephone: '+44 208 109 1015',
		email: site.email,
		address: {
			'@type': 'PostalAddress',
			streetAddress: site.address.line1,
			addressLocality: site.address.town,
			addressRegion: site.address.county,
			postalCode: site.address.postcode,
			addressCountry: 'GB'
		},
		areaServed: 'South of England',
		sameAs: Object.values(site.social)
	};
</script>

<Seo
	title="Jewel Bespoke Build | Loft Conversions, Home Extensions & Renovations in Surrey"
	description={site.description}
	image={images.homeHero}
	jsonLd={jsonLd}
/>

<!-- Hero ------------------------------------------------------------------ -->
<section class="hero">
	<img class="hero__bg" src={images.homeHero} alt="" aria-hidden="true" />
	<div class="hero__scrim" aria-hidden="true"></div>
	<div class="container hero__content">
		<span class="kicker hero__kicker">Family-run · Surrey · 65+ years of experience</span>
		<h1>Welcome to Jewel Bespoke Build</h1>
		<p>
			A family run construction company in Surrey, proudly serving clients across the South of
			England — specialising in high quality loft conversions, tailored home extensions, and
			comprehensive home renovations.
		</p>
		<div class="hero__actions">
			<a href="/contact" class="btn btn--primary">Request a free quote</a>
			<a href="/about" class="btn btn--ghost-light">About us</a>
		</div>
	</div>
</section>

<!-- Services -------------------------------------------------------------- -->
<section class="section">
	<div class="container">
		<span class="kicker">What we do</span>
		<h2>Our services</h2>
		<p class="lede">
			From new builds to loft conversions, every project is delivered with meticulous care,
			craftsmanship, and attention to detail.
		</p>
		<div class="grid grid--3 services-grid">
			{#each services as service (service.slug)}
				<a class="card service-card" href="/services#{service.slug}">
					<h3>{service.title}</h3>
					<p>{service.description.slice(0, 110)}…</p>
					<span class="service-card__more">Learn more →</span>
				</a>
			{/each}
		</div>
	</div>
</section>

<!-- Featured projects ------------------------------------------------------ -->
<section class="section section--tint">
	<div class="container">
		<span class="kicker">Recent projects</span>
		<h2>Built around the way you live</h2>
		<div class="grid grid--3 featured-grid">
			{#each featured as project (project.slug)}
				<a class="card featured" href="/{project.slug}">
					<img src={project.gallery[0]} alt="{project.name} project" loading="lazy" />
					<div class="featured__body">
						<h3>{project.name}</h3>
						<p>{project.subtitle}</p>
					</div>
				</a>
			{/each}
		</div>
		<div class="featured-cta">
			<a href="/portfolio" class="btn btn--outline">View the full portfolio</a>
		</div>
	</div>
</section>

<!-- Testimonial ------------------------------------------------------------ -->
<section class="section">
	<div class="container testimonial-wrap">
		<div>
			<span class="kicker">What clients say</span>
			<h2>Trusted by homeowners and architects alike</h2>
			<p class="lede">
				We build long-term relationships through transparency, clear communication and quality
				that speaks for itself.
			</p>
		</div>
		<TestimonialCard testimonial={testimonials[0]} />
	</div>
</section>

<!-- Badges ----------------------------------------------------------------- -->
<section class="section section--tint badges-section">
	<div class="container">
		<BadgeStrip />
	</div>
</section>

<CtaBand />

<style>
	.hero {
		position: relative;
		min-height: min(88vh, 760px);
		display: flex;
		align-items: center;
		overflow: hidden;
	}

	.hero__bg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		object-fit: cover;
	}

	.hero__scrim {
		position: absolute;
		inset: 0;
		background: linear-gradient(100deg, rgba(13, 21, 33, 0.82) 20%, rgba(13, 21, 33, 0.35) 70%);
	}

	.hero__content {
		position: relative;
		color: #fff;
		max-width: 640px;
		margin-inline: auto;
		padding-block: 6rem;
	}

	.hero__kicker {
		color: var(--gold-300);
	}

	.hero__content h1 {
		color: #fff;
	}

	.hero__content p {
		font-size: 1.15rem;
		color: #dbe3ee;
		margin-bottom: 1.8rem;
	}

	.hero__actions {
		display: flex;
		flex-wrap: wrap;
		gap: 0.9rem;
	}

	.services-grid {
		margin-top: 2.4rem;
	}

	.service-card {
		padding: 1.8rem 1.7rem 1.5rem;
		text-decoration: none;
		display: flex;
		flex-direction: column;
		transition: transform 0.18s ease, box-shadow 0.18s ease;
	}

	.service-card:hover {
		transform: translateY(-3px);
		box-shadow: var(--shadow-lift);
	}

	.service-card p {
		color: var(--ink-600);
		font-size: 0.95rem;
		flex: 1;
	}

	.service-card__more {
		font-weight: 600;
		font-size: 0.9rem;
		color: var(--gold-600);
	}

	.featured-grid {
		margin-top: 2.4rem;
	}

	.featured {
		text-decoration: none;
		overflow: hidden;
		display: flex;
		flex-direction: column;
		transition: transform 0.18s ease, box-shadow 0.18s ease;
	}

	.featured:hover {
		transform: translateY(-3px);
		box-shadow: var(--shadow-lift);
	}

	.featured img {
		aspect-ratio: 3 / 2;
		width: 100%;
		object-fit: cover;
	}

	.featured__body {
		padding: 1.2rem 1.4rem 1.3rem;
	}

	.featured__body p {
		margin: 0;
		color: var(--ink-600);
		font-size: 0.92rem;
	}

	.featured-cta {
		margin-top: 2.2rem;
		text-align: center;
	}

	.testimonial-wrap {
		display: grid;
		gap: 2.5rem;
		align-items: center;
	}

	@media (min-width: 900px) {
		.testimonial-wrap {
			grid-template-columns: 1fr 1.1fr;
		}
	}

	.badges-section {
		padding-block: 2.8rem;
	}
</style>
