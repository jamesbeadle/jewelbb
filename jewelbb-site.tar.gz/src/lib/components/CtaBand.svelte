<script lang="ts">
	interface Props {
		title?: string;
		text?: string;
	}

	let {
		title = 'Build your ideal home that matches your vision and lifestyle.',
		text = 'Let us turn your dream into a reality. Tell us about your project and we will be in touch.'
	}: Props = $props();
</script>

<section class="section section--navy cta">
	<div class="container cta__inner">
		<div>
			<h2>{title}</h2>
			<p class="lede">{text}</p>
		</div>
		<div class="cta__actions">
			<a href="/contact" class="btn btn--primary">Request a free quote</a>
			<a href="/portfolio" class="btn btn--ghost-light">View our work</a>
		</div>
	</div>
</section>

<style>
	.cta__inner {
		display: grid;
		gap: 2rem;
		align-items: center;
	}

	@media (min-width: 860px) {
		.cta__inner {
			grid-template-columns: 1.6fr 1fr;
		}

		.cta__actions {
			justify-self: end;
		}
	}

	.cta__actions {
		display: flex;
		flex-wrap: wrap;
		gap: 0.9rem;
	}
</style>
